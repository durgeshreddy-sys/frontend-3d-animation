---
name: frontend-3d-animation
description: Build and refine interactive 3D web frontends with React, Three.js, React Three Fiber and Tailwind CSS. Use for elastic characters, shader reveals, scroll camera stories, product scenes, GLB character playback, animation blending and motion QA. Distinguishes real 3D from textured planes and prerecorded footage.
---

# Frontend 3D Animation

Deliver a working, inspectable frontend with coherent art direction and purposeful motion. Use React for semantic UI, Tailwind for layout and tokens, R3F for scene lifecycle and Three.js for geometry, materials and animation. Preserve existing project conventions and character identity.

## Ground the brief

Inspect manifests, design context, routes and supplied assets. Extract composition, typography, focal subject, interaction, timing and mobile behavior. Decide whether this is exact reproduction or adaptation. For adaptation, preserve visual intent while using the requested stack; a pasted template's contrary library restrictions do not silently override the current user request.

Record a concise scene brief: desired outcome, asset provenance, rendering method, motion beats, input modes, fallback, performance target and acceptance criteria. Read [prompt analysis](references/prompt-analysis.md) for the thirteen supplied examples and their conflicts; [architecture](references/architecture.md) for new projects. Do not load all references for a narrow task.

## Choose the workflow

| Request | Read / execute |
|---|---|
| New hero or runnable starting point | [Starter](references/starter.md); `python3 scripts/scaffold.py <new-directory>` |
| Elastic face, cursor trail, fog or paint reveal | [Interactions](references/interactions.md) |
| Scroll narrative, orbit, macro product shot, rewind | [Camera](references/camera.md) |
| GLB mascot, imported clips, Mixamo, joint rig | [Characters](references/characters.md), [motion quality](references/motion-quality.md) |
| Inspect images, sprite parts, GLB/glTF | [Assets](references/assets.md); `python3 scripts/inspect_asset.py <path>` |
| Spine or 2D cutout integration | [Spine bridge](references/spine-bridge.md) |
| Choose an additional animation/video/audio library | [Tool selection](references/tool-selection.md) |
| Finish or review | [Verification](references/verification.md); `python3 scripts/validate_motion.py <motion.json>` for the bundled format |

Resolve script paths relative to this skill directory. Scaffolding creates an absent destination and does not install packages. Adapt components into existing apps; never scaffold over them. The example uses JavaScript/JSX; preserve TypeScript when already present or requested.

## Implementation invariants

- Keep headings, navigation, forms and controls in the DOM. Canvas cannot be the only means of understanding or operating the page. Give drag interactions a button or keyboard equivalent.
- Assign one owner to each animated property. OrbitControls, scroll and intro timelines cannot independently write the same camera. Compose root motion, clip pose and secondary offsets deliberately.
- Put frame updates in refs and `useFrame`; React state holds discrete states. Use seconds-based deltas, bounded physics steps and preallocated vectors/materials.
- Keep scenes mounted across view changes. Reuse stable uniforms and resources. Dispose owned GPU objects; preserve cached assets still used elsewhere.
- Check React/R3F peer versions and installed APIs. The example baseline is React 19 + Fiber 9 and Tailwind 4 via its Vite plugin; do not force these versions onto existing apps.
- A textured dense plane is 2.5D, and a video remains prerecorded media. Actual 3D requires geometry. One picture cannot supply hidden surfaces, topology or skin weights.
- Decode assets before reveal. Distinguish measured loading from theatrical intro progress. Handle failures and never trap content behind a perpetual preloader.
- Respect reduced motion, tab visibility, mobile scrolling and renderer loss. Skip involuntary camera travel/bounce while retaining instant user controls. Supply pause for repeating motion.
- Record asset origin/use restrictions. A URL in a reference does not grant redistribution rights. Mixamo is motion-only: no Mixamo character meshes/textures, invented API or authentication bypass.
- Treat procedural presets as starting poses, not universal mocap. Report missing joints, rest-pose differences and unmeasured contact behavior.

## Verify and deliver

Build and run the result. Exercise desktop/mobile, keyboard, pointer release/cancel, rapid switching, reduced motion and unavailable WebGL. Inspect rendered silhouette, text contrast, framing and seams; check deformed normals/shadows when introducing shaders.

The Python motion validator checks structure, not visual finish or foot contact. Reimport GLB exports. Claim Spine compatibility only after testing the matching official runtime. Deliver files, launch commands, key decisions, actual test evidence and unresolved limits.

[Research](references/research.md) describes the upstream investigation. [Package quality report](references/quality-report.md) records this package's tests, not validation of future user assets or devices.
