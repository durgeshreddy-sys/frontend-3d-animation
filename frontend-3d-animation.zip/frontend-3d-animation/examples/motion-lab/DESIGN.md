# Motion study

Purpose: an approachable character motion study with a large original clay-like mascot and directly operable playback controls. Audience: designers and developers inspecting timing. One page, no commerce or user data.

Layout: pale blue stage beside an oversized tightly spaced headline, with a compact playback bench below. The orange elongated head and asymmetrical ear tips are the signature. No stock artwork or third-party fonts.

Runtime token owner: `src/style.css` @theme and :root. Paper #e8f0f6; ink #16374b; muted #526978; actor orange #ed7751; stage blue #cbdfe9; line #b4cbd8. UI uses system sans, display uses a heavy system sans, numeric metadata uses system monospace. Minimum control height 44px, clear blue focus rings. Native select popup appearance is accepted.

Behavior: every animation preset is a button; playback can pause, seek and change speed. Reduced motion starts paused and reacts to preference changes. A static original SVG and all DOM controls remain when WebGL is unavailable. The example exports its authored data and a neutral articulated model with clips. It is a preview, not a full animation editor.
