import test from 'node:test';
import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';
import {AnimationMixer,LoopOnce} from 'three';
import {springStep,sampleBeats,compileClips,damp} from '../src/motion.js';
import {createRig} from '../src/rig.js';
const data=JSON.parse(readFileSync(new URL('../src/motion.json',import.meta.url)));

test('spring is frame-rate independent and settles',()=>{
  const step=fps=>{let state=[.7,1];for(let i=0;i<fps*3;i++)state=springStep(...state,1/fps);return state;};
  const a=step(30),b=step(144);assert.ok(Math.abs(a[0]-b[0])<1e-10);assert.ok(Math.abs(a[0])+Math.abs(a[1])<1e-6);
});
test('damping composes across frame rates',()=>assert.ok(Math.abs(damp(damp(0,1,5,.1),1,5,.1)-damp(0,1,5,.2))<1e-12));
test('camera holds and explicit rewind stay inside their segments',()=>{
  const beats=[[0,0],[.2,0],[.6,10],[.8,10],[1,0]];
  assert.equal(sampleBeats(beats,.1),0);assert.equal(sampleBeats(beats,.7),10);
  let previous=10;for(let t=.8;t<=1;t+=.01){const next=sampleBeats(beats,t);assert.ok(next<=previous+1e-8);assert.ok(next>=0);previous=next;}
  assert.throws(()=>sampleBeats([[0,0],[0,1]],.2));
});
test('all clips bind to real joints and remain finite at sampled times',()=>{
  const rig=createRig(data),clips=compileClips(data),mixer=new AnimationMixer(rig.root);
  for(const clip of clips){
    const action=mixer.clipAction(clip).setLoop(LoopOnce,1);action.clampWhenFinished=true;action.play();
    for(let i=0;i<=10;i++){action.time=clip.duration*i/10;action.paused=false;mixer.update(0);rig.root.updateMatrixWorld(true);for(const b of rig.bones.values())assert.ok(b.matrixWorld.elements.every(Number.isFinite));}
    action.stop();
  }
  mixer.uncacheRoot(rig.root);rig.dispose();assert.equal(clips.length,8);
});
test('jump has anticipation and airborne phase, wave moves the arm',()=>{
  const jump=data.clips.find(c=>c.name==='jump').tracks.find(t=>t.path==='position');
  assert.ok(jump.values[1][1]<jump.values[0][1]);assert.ok(Math.max(...jump.values.map(v=>v[1]))>1.7);
  const wave=data.clips.find(c=>c.name==='wave').tracks.find(t=>t.bone==='rightArm');assert.notDeepEqual(wave.values[0],wave.values[1]);
});
