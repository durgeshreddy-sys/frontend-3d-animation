import { chromium, expect } from '@playwright/test';
import assert from 'node:assert/strict';
import { mkdir } from 'node:fs/promises';
const browser=await chromium.launch({headless:true,executablePath:process.env.BROWSER_PATH||undefined,args:['--no-sandbox','--use-angle=swiftshader','--enable-unsafe-swiftshader']});
const url=process.env.PREVIEW_URL||'http://127.0.0.1:5173';
await mkdir('test-results',{recursive:true});
const page=await browser.newPage({viewport:{width:1440,height:1000}}),errors=[];
page.on('pageerror',error=>errors.push(error.message));
try{
  await page.goto(url);await page.waitForSelector('[data-ready="true"]');
  await page.getByRole('button',{name:'Pause',exact:true}).click();
  for(const name of ['idle','walk','run','jump','fall','land','turn','wave']){
    await page.getByRole('button',{name,exact:true}).click();
    assert.equal(await page.getByRole('button',{name,exact:true}).getAttribute('aria-pressed'),'true');
  }
  await page.getByRole('button',{name:'idle',exact:true}).click();
  await page.screenshot({path:'test-results/desktop.png',fullPage:true});
  await page.getByRole('button',{name:'jump',exact:true}).click();
  await page.getByLabel('Playhead').fill('0.6');
  await page.getByText('0.60 / 1.50 s',{exact:true}).waitFor();
  await page.screenshot({path:'test-results/jump.png',fullPage:true});
  await page.getByRole('button',{name:'Play',exact:true}).click();
  await expect(page.getByRole('button',{name:'Play',exact:true})).toBeVisible({timeout:10000});
  await page.getByRole('button',{name:'Play',exact:true}).click();
  await expect(page.getByRole('button',{name:'Pause',exact:true})).toBeVisible();
  await page.getByRole('button',{name:'Pause',exact:true}).click();
  await page.getByRole('button',{name:'idle',exact:true}).click();
  await page.getByLabel('Show bones').check();
  await page.getByLabel('Speed').selectOption('0.5');
  await page.getByLabel('Playhead').fill('0.7');
  await page.waitForFunction(()=>document.querySelector('#timeline').value==='0.7');
  const pull=page.getByRole('button',{name:'Stretch character head'});await pull.focus();await page.keyboard.press('Enter');
  const bounds=await pull.boundingBox();await page.mouse.move(bounds.x+10,bounds.y+10);await page.mouse.down();await page.mouse.move(bounds.x+10,bounds.y-70);await page.mouse.up();
  await pull.dispatchEvent('pointercancel',{pointerId:1});
  const downloadEvent=page.waitForEvent('download');await page.getByRole('button',{name:'Export model'}).click();const download=await downloadEvent;await download.saveAs('test-results/motion-study.glb');
  const roundtrip=await page.evaluate(async()=>{
    const [{exportGLB},{GLTFLoader},motion]=await Promise.all([import('/src/export.js'),import('/node_modules/three/examples/jsm/loaders/GLTFLoader.js'),import('/src/motion.json')]);
    const binary=await exportGLB(motion.default);const parsed=await new GLTFLoader().parseAsync(binary,'');
    return {names:parsed.animations.map(c=>c.name),durations:parsed.animations.map(c=>c.duration),head:!!parsed.scene.getObjectByName('head')};
  });
  assert.equal(roundtrip.names.length,8);assert.equal(roundtrip.head,true);assert.ok(roundtrip.durations.every(d=>d>0));
  const jsonEvent=page.waitForEvent('download');await page.getByRole('button',{name:'Save motion data'}).click();await (await jsonEvent).saveAs('test-results/motion-study.json');
  await page.setViewportSize({width:390,height:844});await page.screenshot({path:'test-results/mobile.png',fullPage:true});
  assert.equal(await page.evaluate(()=>document.documentElement.scrollWidth<=innerWidth),true);
  await page.emulateMedia({reducedMotion:'reduce'});await expect(pull).toBeDisabled();await expect(page.getByRole('button',{name:'Play',exact:true})).toBeVisible();
  await page.evaluate(()=>document.querySelector('canvas').dispatchEvent(new Event('webglcontextlost',{cancelable:true})));
  await page.getByText('3D unavailable. The still and downloads remain available.').waitFor();
  assert.equal(errors.length,0,errors.join('\n'));
  const fallback=await browser.newPage();await fallback.addInitScript(()=>{const original=HTMLCanvasElement.prototype.getContext;HTMLCanvasElement.prototype.getContext=function(kind,...args){return /webgl/.test(kind)?null:original.call(this,kind,...args);};});
  await fallback.goto(url);await fallback.getByRole('heading',{name:'A little more life.'}).waitFor();await fallback.getByRole('img',{name:'Orange long-eared mascot standing at rest'}).first().waitFor();await fallback.close();
  console.log(JSON.stringify({ok:true,checks:['eight presets','play/pause and one-shot replay','seek','speed','bones','keyboard nudge','pointer release/cancel','JSON download','GLB download and reimport','desktop/mobile/jump screenshots','no mobile overflow','reduced motion change','context loss','WebGL unavailable'],roundtrip},null,2));
}finally{await browser.close();}
