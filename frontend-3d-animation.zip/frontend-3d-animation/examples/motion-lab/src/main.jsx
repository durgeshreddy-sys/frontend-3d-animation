import React, { Component, StrictMode, useCallback, useEffect, useRef, useState } from 'react';
import { createRoot } from 'react-dom/client';
import { Canvas } from '@react-three/fiber';
import Scene from './Scene';
import data from './motion.json';
import { download, exportGLB } from './export';
import './style.css';

class Boundary extends Component {
  state={failed:false};
  static getDerivedStateFromError(){return {failed:true};}
  componentDidCatch(){this.props.onError();}
  render(){return this.state.failed?null:this.props.children;}
}
function Poster(){return <svg viewBox="0 0 400 440" aria-label="Orange long-eared mascot standing at rest" role="img" className="poster"><ellipse cx="200" cy="402" rx="85" ry="15" fill="#a8c3d1"/><path d="M171 320v70m58-70v70" stroke="#16374b" strokeWidth="32" strokeLinecap="round"/><ellipse cx="200" cy="285" rx="57" ry="67" fill="#ed7751"/><path d="M147 274l-22 66m128-66 22 66" stroke="#ed7751" strokeWidth="23" strokeLinecap="round"/><ellipse cx="161" cy="115" rx="20" ry="61" fill="#ed7751"/><ellipse cx="237" cy="122" rx="20" ry="51" fill="#ed7751"/><ellipse cx="200" cy="193" rx="77" ry="81" fill="#ed7751"/><g fill="#fff3d7"><ellipse cx="173" cy="185" rx="19" ry="22"/><ellipse cx="227" cy="185" rx="19" ry="22"/></g><g fill="#16374b"><ellipse cx="176" cy="189" rx="7" ry="11"/><ellipse cx="230" cy="189" rx="7" ry="11"/><ellipse cx="202" cy="222" rx="14" ry="8"/></g></svg>;}
function App(){
  const [selected,setSelected]=useState(0),[paused,setPaused]=useState(()=>matchMedia('(prefers-reduced-motion: reduce)').matches);
  const [reduced,setReduced]=useState(()=>matchMedia('(prefers-reduced-motion: reduce)').matches);
  const [active,setActive]=useState(!document.hidden),[speed,setSpeed]=useState(1),[seek,setSeek]=useState({time:0,id:0});
  const [bones,setBones]=useState(false),[nudge,setNudge]=useState(0),[ready,setReady]=useState(false),[failed,setFailed]=useState(false),[busy,setBusy]=useState(false),[status,setStatus]=useState('');
  const timeRef=useRef(0),rangeRef=useRef(null),readoutRef=useRef(null),dragRef=useRef({held:false,amount:0,start:0,id:null});
  const clip=data.clips[selected];
  const onReady=useCallback(()=>setReady(true),[]),onLost=useCallback(()=>{setFailed(true);setReady(false);},[]);
  const onFinished=useCallback(()=>setPaused(true),[]);
  useEffect(()=>{
    const media=matchMedia('(prefers-reduced-motion: reduce)');
    const change=()=>{setReduced(media.matches);if(media.matches)setPaused(true);};
    const visibility=()=>setActive(!document.hidden);
    const release=()=>{dragRef.current.held=false;dragRef.current.id=null;};
    media.addEventListener('change',change);document.addEventListener('visibilitychange',visibility);window.addEventListener('blur',release);
    return()=>{media.removeEventListener('change',change);document.removeEventListener('visibilitychange',visibility);window.removeEventListener('blur',release);};
  },[]);
  useEffect(()=>{const sync=()=>{if(rangeRef.current)rangeRef.current.value=timeRef.current;if(readoutRef.current)readoutRef.current.textContent=`${timeRef.current.toFixed(2)} / ${clip.duration.toFixed(2)} s`;};sync();const id=setInterval(sync,100);return()=>clearInterval(id);},[clip]);
  async function saveGLB(){setBusy(true);setStatus('Preparing model…');try{download(await exportGLB(data),'motion-study.glb','model/gltf-binary');setStatus('Model exported with eight animations.');}catch(error){setStatus(`Export failed: ${error.message}`);}finally{setBusy(false);}}
  function release(e){if(dragRef.current.id!==e.pointerId)return;dragRef.current.held=false;dragRef.current.id=null;if(e.currentTarget.hasPointerCapture(e.pointerId))e.currentTarget.releasePointerCapture(e.pointerId);}
  return <main className="mx-auto max-w-[1600px] px-5 md:px-12">
    <header className="flex items-center justify-between py-7 border-b border-line"><a href="#study" className="font-bold text-lg tracking-tight">little moves<span className="text-orange">®</span></a><span className="font-mono text-xs uppercase tracking-widest">An interactive motion study</span></header>
    <section id="study" className="grid lg:grid-cols-[.8fr_1.2fr] gap-8 lg:gap-14 py-10 lg:py-16 items-center">
      <div><p className="font-mono text-xs uppercase tracking-[.22em] mb-6">A character in the making</p><h1 className="text-[clamp(4rem,8vw,8rem)] font-black tracking-[-.075em] leading-[.88]">A little<br/>more <em className="font-normal">life.</em></h1><p className="mt-7 max-w-sm text-muted text-lg leading-relaxed">A pause. A step. A wave hello.<br/>Small movements give a character<br className="hidden md:block"/> a personality of its own.</p><p className="mt-8 text-sm max-w-xs">Choose a movement, slow it down, and find the moment it comes alive.</p></div>
      <div className="stage relative overflow-hidden rounded-[3rem]" aria-label="Character preview" data-ready={ready && !failed}>
        {(!ready || failed)&&<Poster/>}
        {!failed&&<Boundary onError={onLost}><Canvas camera={{position:[3,2.8,7],fov:40}} dpr={[1,1.5]} frameloop={paused||!active?'demand':'always'} onCreated={({camera})=>camera.lookAt(0,1.85,0)} fallback={<Poster/>}><Scene {...{selected,paused,speed,seek,reduced,nudge,onReady,onLost,onFinished,timeRef,dragRef,active}} bonesVisible={bones}/></Canvas></Boundary>}
        <div className="absolute left-6 top-6 font-mono text-xs uppercase tracking-widest">{failed?'Still study':clip.name}</div>
        <button type="button" className="stretch-pad absolute right-5 top-5" disabled={reduced||failed} aria-label="Stretch character head" onClick={e=>{if(e.detail===0)setNudge(v=>v+1);}} onPointerDown={e=>{if(dragRef.current.held)return;e.currentTarget.setPointerCapture(e.pointerId);dragRef.current={held:true,amount:.15,start:e.clientY,id:e.pointerId};setNudge(v=>v+1);}} onPointerMove={e=>{if(dragRef.current.held&&dragRef.current.id===e.pointerId)dragRef.current.amount=.5*Math.tanh((dragRef.current.start-e.clientY+25)/100);}} onPointerUp={release} onPointerCancel={release} onLostPointerCapture={release}>Pull ↕</button>
        <div className="absolute bottom-5 left-6 right-6 flex justify-between text-xs text-ink/80"><span>{failed?'3D unavailable. The still and downloads remain available.':'Meet Pip. A small study in motion.'}</span><span aria-hidden="true">✳</span></div>
      </div>
    </section>
    <section aria-label="Playback controls" className="pb-8">
      <div className="flex flex-wrap gap-2 mb-6" aria-label="Choose a movement">{data.clips.map((c,i)=><button key={c.name} type="button" className={`preset ${i===selected?'selected':''}`} aria-pressed={i===selected} onClick={()=>{setSelected(i);timeRef.current=0;setSeek(v=>({time:0,id:v.id+1}));}}>{c.name}</button>)}</div>
      <div className="controls grid gap-5 md:grid-cols-[auto_1fr_auto] items-center border-y border-line py-5">
        <button className="action min-w-28" type="button" disabled={failed} onClick={()=>{if(paused && timeRef.current>=clip.duration-0.001){timeRef.current=0;setSeek(v=>({time:0,id:v.id+1}));}setPaused(v=>!v);}}>{paused?'Play':'Pause'}</button>
        <div><label htmlFor="timeline" className="flex justify-between text-xs mb-2"><span>Playhead</span><span ref={readoutRef} className="font-mono">0.00 / {clip.duration.toFixed(2)} s</span></label><input ref={rangeRef} id="timeline" type="range" min="0" max={clip.duration} step="0.001" defaultValue="0" disabled={failed} onChange={e=>{const time=Number(e.target.value);setPaused(true);setSeek(v=>({time,id:v.id+1}));timeRef.current=time;}}/><div className="relative h-2" aria-hidden="true">{clip.beats.map(t=><i key={t} className="absolute h-1 w-1 rounded-full bg-ink/40" style={{left:`${t*100}%`}}/>)}</div></div>
        <div className="flex gap-5 items-center"><label className="text-xs">Speed <select value={speed} onChange={e=>setSpeed(Number(e.target.value))}>{[.25,.5,1,1.5,2].map(s=><option key={s} value={s}>{s}×</option>)}</select></label><label className="flex gap-2 text-xs items-center min-h-11"><input type="checkbox" checked={bones} onChange={e=>setBones(e.target.checked)}/>Show bones</label></div>
      </div>
      <div className="flex flex-wrap justify-between gap-4 pt-5 text-sm"><p className="text-muted max-w-lg">{clip.description}{reduced?' Reduced motion: playback starts paused.':''}</p><div className="flex gap-4"><button type="button" className="text-link" onClick={()=>download(JSON.stringify(data,null,2),'motion-study.json','application/json')}>Save motion data ↗</button><button type="button" className="text-link" disabled={busy} onClick={saveGLB}>Export model ↗</button></div></div>
      <p role="status" className="min-h-6 text-sm mt-2">{status}</p>
    </section>
    <footer className="flex flex-wrap justify-between gap-4 py-5 text-xs text-muted border-t border-line"><span>Original character · Eight movement studies</span><span>Illustrative poses. Foot contact still needs refinement.</span></footer>
  </main>;
}
createRoot(document.getElementById('root')).render(<StrictMode><App/></StrictMode>);
