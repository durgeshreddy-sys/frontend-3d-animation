import { GLTFExporter } from 'three/addons/exporters/GLTFExporter.js';
import { createRig } from './rig';
import { compileClips } from './motion';

export function download(data,name,type) {
  const url=URL.createObjectURL(new Blob([data],{type}));
  const link=document.createElement('a'); link.href=url; link.download=name; link.click();
  setTimeout(()=>URL.revokeObjectURL(url),1000);
}

export async function exportGLB(data) {
  // Export a new neutral rig so a currently playing pose never becomes its bind/setup pose.
  const rig=createRig(data);
  try { return await new GLTFExporter().parseAsync(rig.root,{binary:true,trs:true,animations:compileClips(data)}); }
  finally { rig.dispose(); }
}
