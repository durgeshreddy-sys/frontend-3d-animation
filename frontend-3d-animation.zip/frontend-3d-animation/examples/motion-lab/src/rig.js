import { Bone, Group, Mesh, MeshStandardMaterial, SphereGeometry } from 'three';

// Original articulated primitive mascot. Rigid parts attached to bones, not a weighted skin.
export function createRig(data) {
  const root=new Group(); root.name='MotionStudy';
  const bones=new Map(), geometry=new SphereGeometry(1,32,20);
  const materials={ clay:new MeshStandardMaterial({color:'#ed7751',roughness:.68}),
    dark:new MeshStandardMaterial({color:'#16374b',roughness:.6}),
    cream:new MeshStandardMaterial({color:'#fff3d7',roughness:.7}) };
  for(const b of data.bones){ const node=new Bone(); node.name=b.name; node.position.fromArray(b.position); bones.set(b.name,node); }
  for(const b of data.bones) (b.parent?bones.get(b.parent):root).add(bones.get(b.name));
  const part=(parent,position,scale,material='clay')=>{
    const mesh=new Mesh(geometry,materials[material]); mesh.position.fromArray(position); mesh.scale.fromArray(scale); parent.add(mesh); return mesh;
  };
  part(bones.get('chest'),[0,0,0],[.4,.48,.29]);
  const headVisual=new Group(); headVisual.name='headShape'; bones.get('head').add(headVisual);
  part(headVisual,[0,.2,0],[.56,.65,.44]);
  const leftEar=part(headVisual,[-.35,.77,0],[.16,.4,.15]); leftEar.rotation.z=.22;
  const rightEar=part(headVisual,[.35,.77,0],[.16,.32,.15]); rightEar.rotation.z=-.22;
  for(const x of [-.2,.2]){ part(headVisual,[x,.3,.38],[.14,.17,.08],'cream'); part(headVisual,[x,.29,.45],[.055,.085,.035],'dark'); }
  part(headVisual,[0,.03,.43],[.11,.07,.08],'dark');
  for(const side of ['left','right']){
    part(bones.get(side+'Arm'),[0,-.2,0],[.12,.28,.12]);
    part(bones.get(side+'Forearm'),[0,-.18,0],[.1,.24,.1]);
    part(bones.get(side+'Thigh'),[0,-.24,0],[.16,.29,.16],'dark');
    part(bones.get(side+'Shin'),[0,-.22,0],[.13,.27,.13],'dark');
    part(bones.get(side+'Shin'),[0,-.49,.1],[.18,.12,.29],'cream');
  }
  return {root,bones,headVisual,dispose(){geometry.dispose(); Object.values(materials).forEach(m=>m.dispose());}};
}
