import { AnimationClip, QuaternionKeyframeTrack, VectorKeyframeTrack } from 'three';

export const clamp = (n, a = 0, b = 1) => Math.min(b, Math.max(a, n));
export const damp = (current, target, rate, dt) => current + (target-current) * (1-Math.exp(-rate*Math.max(0,dt)));

// Exact underdamped spring solution, including velocity; no frame-count dependency.
export function springStep(x, v, dt, stiffness = 180, damping = 12) {
  if (![x,v,dt,stiffness,damping].every(Number.isFinite) || dt < 0 || stiffness <= 0 || damping < 0 || damping*damping >= 4*stiffness) throw new Error('Expected finite underdamped spring parameters');
  const a=damping/2, w=Math.sqrt(stiffness-a*a), decay=Math.exp(-a*dt);
  const c=Math.cos(w*dt), s=Math.sin(w*dt), b=(v+a*x)/w;
  return [decay*(x*c+b*s), decay*(v*c-(a*v+stiffness*x)/w*s)];
}

// Piecewise direction-preserving interpolation: holds and intentional rewind are valid.
export function sampleBeats(beats, progress) {
  if (beats.length<2 || beats.some((b,i)=>b.length!==2 || !b.every(Number.isFinite) || (i>0 && b[0]<=beats[i-1][0]))) throw new Error('Invalid beat coordinates');
  const p=clamp(progress,beats[0][0],beats.at(-1)[0]);
  let i=0; while(i<beats.length-2 && p>beats[i+1][0]) i++;
  const [x0,y0]=beats[i], [x1,y1]=beats[i+1];
  const t=(p-x0)/(x1-x0), k=t*t*(3-2*t);
  return y0+(y1-y0)*k;
}

export function compileClips(data) {
  const names = new Set(data.bones.map(b=>b.name));
  return data.clips.map(clip=>new AnimationClip(clip.name,clip.duration,clip.tracks.map(track=>{
    if (!names.has(track.bone)) throw new Error(`Missing bone: ${track.bone}`);
    const Track=track.path==='quaternion'?QuaternionKeyframeTrack:VectorKeyframeTrack;
    return new Track(`${track.bone}.${track.path}`,track.times,track.values.flat());
  })));
}
