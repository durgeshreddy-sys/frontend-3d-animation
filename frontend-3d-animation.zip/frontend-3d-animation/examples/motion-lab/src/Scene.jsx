import { useEffect, useMemo, useRef } from 'react';
import { useFrame, useThree } from '@react-three/fiber';
import { AnimationMixer, LoopOnce, LoopRepeat, SkeletonHelper } from 'three';
import { createRig } from './rig';
import { compileClips, springStep, damp } from './motion';
import data from './motion.json';

export default function Scene({ selected, paused, speed, seek, bonesVisible, reduced, nudge, onReady, onLost, onFinished, timeRef, dragRef, active }) {
  const rig=useMemo(()=>createRig(data),[]);
  const mixer=useMemo(()=>new AnimationMixer(rig.root),[rig]);
  const clips=useMemo(()=>compileClips(data),[]);
  const helper=useMemo(()=>new SkeletonHelper(rig.root),[rig]);
  const action=useRef(null), spring=useRef([0,0]);
  const {gl,invalidate}=useThree();
  useEffect(()=>{
    onReady();
    const lost=e=>{e.preventDefault();onLost();};
    gl.domElement.addEventListener('webglcontextlost',lost);
    return()=>gl.domElement.removeEventListener('webglcontextlost',lost);
  },[gl,onReady,onLost]);
  useEffect(()=>()=>{mixer.stopAllAction();mixer.uncacheRoot(rig.root);rig.dispose();helper.geometry.dispose();helper.material.dispose();},[rig,mixer,helper]);
  useEffect(()=>{
    const next=mixer.clipAction(clips[selected]);
    const previous=action.current;
    if(previous && previous!==next) previous.stop();
    next.reset().setLoop(data.clips[selected].loop?LoopRepeat:LoopOnce,Infinity);
    next.clampWhenFinished=true; next.play(); action.current=next;
    // Explicit selection is immediate. See the skill for crossfade/contact phase matching.
    mixer.update(0); timeRef.current=0; invalidate();
    return()=>next.stop();
  },[selected,clips,mixer,invalidate,timeRef]);
  useEffect(()=>{ if(action.current){action.current.time=seek.time;action.current.paused=false;mixer.update(0);timeRef.current=seek.time;invalidate();}},[seek,mixer,timeRef,invalidate]);
  useEffect(()=>{ if(!reduced && nudge>0){spring.current=[.2,1.2];invalidate();}},[nudge,reduced,invalidate]);
  useEffect(()=>{if(reduced){spring.current=[0,0];rig.headVisual.scale.setScalar(1);invalidate();}},[reduced,rig,invalidate]);
  useFrame((_,delta)=>{
    const dt=Math.min(delta,1/30);
    if(!paused && active){
      mixer.update(dt*speed);timeRef.current=action.current?.time ?? 0;
      // Completion is a discrete UI event, not a per-frame React state update.
      if(!data.clips[selected].loop && timeRef.current>=data.clips[selected].duration) onFinished();
    }
    let [x,v]=spring.current;
    if(!reduced && active){
      if(dragRef.current.held){const next=damp(x,dragRef.current.amount,24,dt);v=dt?(next-x)/dt:0;x=next;}
      else [x,v]=springStep(x,v,dt);
      spring.current=[x,v];
      const stretch=Math.max(.65,1+x);rig.headVisual.scale.set(1/Math.sqrt(stretch),stretch,1/Math.sqrt(stretch));
      if(Math.abs(x)+Math.abs(v)>.001 || dragRef.current.held) invalidate();
    }
    helper.visible=bonesVisible;
  });
  return <>
    <color attach="background" args={['#cbdfe9']}/>
    <hemisphereLight args={['#fff8ee','#53798b',2]}/>
    <directionalLight position={[-3,6,4]} intensity={3}/>
    <group rotation={[0,-.25,0]}><primitive object={rig.root} dispose={null}/><primitive object={helper} dispose={null}/></group>
    <mesh rotation={[-Math.PI/2,0,0]} position={[0,-.06,0]} scale={[1,.65,1]}><circleGeometry args={[.9,48]}/><meshBasicMaterial color="#a8c3d1"/></mesh>
  </>;
}
