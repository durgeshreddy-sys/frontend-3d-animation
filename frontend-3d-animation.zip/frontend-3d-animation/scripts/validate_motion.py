#!/usr/bin/env python3
"""Validate motion-lab/v1 authored data. This is not a glTF or Spine validator."""
import argparse
import json
import math
from pathlib import Path


def finite(value):
    return isinstance(value, (int, float)) and not isinstance(value, bool) and math.isfinite(value)


def vector(value, size):
    return isinstance(value, list) and len(value) == size and all(map(finite, value))


def validate(data):
    errors, warnings = [], []
    if not isinstance(data, dict) or data.get("format") != "motion-lab/v1":
        return {"ok": False, "errors": ["Expected motion-lab/v1 object"], "warnings": []}
    bones, clips = data.get("bones"), data.get("clips")
    if not isinstance(bones, list) or not bones or not isinstance(clips, list) or not clips:
        return {"ok": False, "errors": ["Nonempty bones and clips arrays required"], "warnings": []}
    parents = {}
    for bone in bones:
        if not isinstance(bone, dict) or not isinstance(bone.get("name"), str) or not bone["name"]:
            errors.append("Bone requires a nonempty name"); continue
        name = bone["name"]
        if name in parents: errors.append(f"Duplicate bone: {name}")
        parents[name] = bone.get("parent")
        if not vector(bone.get("position"), 3): errors.append(f"{name}: invalid rest position")
    for name, parent in parents.items():
        if parent is not None and (not isinstance(parent, str) or parent not in parents):
            errors.append(f"{name}: unknown parent {parent!r}")
    for name in parents:
        seen, current = set(), name
        while isinstance(current, str) and current in parents:
            if current in seen:
                errors.append(f"Hierarchy cycle at {current}"); break
            seen.add(current); current = parents[current]
    if sum(p is None for p in parents.values()) != 1:
        errors.append("Canonical fixture requires exactly one root")
    names = set()
    for clip in clips:
        if not isinstance(clip, dict): errors.append("Clip must be an object"); continue
        name, duration = clip.get("name"), clip.get("duration")
        if not isinstance(name, str) or not name:
            errors.append("Clip needs a name"); name = "unnamed"
        if name in names: errors.append(f"Duplicate clip: {name}")
        names.add(name)
        if not finite(duration) or duration <= 0:
            errors.append(f"{name}: invalid duration"); continue
        if not finite(clip.get("fps")) or clip["fps"] <= 0: errors.append(f"{name}: invalid authoring fps")
        if not isinstance(clip.get("loop"), bool): errors.append(f"{name}: loop must be boolean")
        tracks = clip.get("tracks")
        if not isinstance(tracks, list) or not tracks: errors.append(f"{name}: no tracks"); continue
        bindings = set()
        for track in tracks:
            if not isinstance(track, dict): errors.append(f"{name}: track must be an object"); continue
            bone, path = track.get("bone"), track.get("path")
            label = f"{name}/{bone}/{path}"
            if not isinstance(bone, str) or bone not in parents: errors.append(f"{label}: unknown bone")
            if path not in ("position", "quaternion", "scale"):
                errors.append(f"{label}: unsupported path"); continue
            binding = (str(bone), path)
            if binding in bindings: errors.append(f"{label}: duplicate binding")
            bindings.add(binding)
            times, values = track.get("times"), track.get("values")
            if not isinstance(times, list) or len(times) < 2 or not all(map(finite, times)):
                errors.append(f"{label}: at least two finite times required"); continue
            if any(b <= a for a, b in zip(times, times[1:])):
                errors.append(f"{label}: times must increase strictly")
            if abs(times[0]) > 1e-6 or abs(times[-1] - duration) > 1e-6:
                errors.append(f"{label}: tracks must span 0 through clip duration")
            size = 4 if path == "quaternion" else 3
            if not isinstance(values, list) or len(values) != len(times) or not all(vector(v, size) for v in values):
                errors.append(f"{label}: invalid finite values or sample count"); continue
            if path == "quaternion" and any(abs(sum(x*x for x in v)-1) > 0.002 for v in values):
                errors.append(f"{label}: quaternion must be normalized")
            if path == "scale" and any(x <= 0 for v in values for x in v):
                errors.append(f"{label}: nonpositive scale")
            if clip.get("loop"):
                a, b = values[0], values[-1]
                gap = min(max(abs(x-y) for x,y in zip(a,b)), max(abs(x+y) for x,y in zip(a,b))) if size == 4 else max(abs(x-y) for x,y in zip(a,b))
                if gap > 0.001: errors.append(f"{label}: loop pose discontinuity")
                if size == 3 and len(times) > 2 and times[1] > times[0] and times[-1] > times[-2]:
                    start = [(b-a)/(times[1]-times[0]) for a,b in zip(values[0],values[1])]
                    end = [(b-a)/(times[-1]-times[-2]) for a,b in zip(values[-2],values[-1])]
                    if max(abs(a-b) for a,b in zip(start,end)) > 0.1:
                        warnings.append(f"{label}: linear endpoint velocities differ; inspect loop seam")
    warnings.append("Foot contact, skin weights, quaternion angular velocity and visual quality are not measured.")
    return {"ok": not errors, "errors": errors, "warnings": warnings, "bones": len(parents), "clips": len(clips)}


if __name__ == "__main__":
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("file", type=Path)
    a = p.parse_args()
    try:
        report = validate(json.loads(a.file.read_text()))
    except (OSError, ValueError, TypeError) as exc:
        report = {"ok": False, "errors": [str(exc)], "warnings": []}
    print(json.dumps(report, indent=2, allow_nan=False))
    raise SystemExit(0 if report["ok"] else 1)
