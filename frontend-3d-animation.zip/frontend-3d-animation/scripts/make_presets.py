#!/usr/bin/env python3
"""Generate original illustrative key-pose presets for the bundled canonical rig."""
import argparse
import json
import math
from pathlib import Path


def generate():
    bones = [{"name": "root", "parent": None, "position": [0,0,0]},
             {"name": "hips", "parent": "root", "position": [0,1.12,0]},
             {"name": "chest", "parent": "hips", "position": [0,.38,0]},
             {"name": "head", "parent": "chest", "position": [0,.65,0]}]
    for side, sign in [("left", -1), ("right", 1)]:
        bones.extend([
            {"name": side+"Arm", "parent": "chest", "position": [sign*.42,.23,0]},
            {"name": side+"Forearm", "parent": side+"Arm", "position": [0,-.4,0]},
            {"name": side+"Thigh", "parent": "hips", "position": [sign*.23,0,0]},
            {"name": side+"Shin", "parent": side+"Thigh", "position": [0,-.48,0]},
        ])
    def pose(height=0, **angles): return {"height": height, **angles}
    idle = [pose(),pose(.018,chest=2,head=-2,leftArm=3,rightArm=-2),pose(),pose(-.008,chest=-1,head=1),pose()]
    def gait(run=False):
        a = 36 if run else 23; b = 65 if run else 38
        first = pose(0,leftThigh=-a,rightThigh=a,leftShin=10,rightShin=b,leftArm=a,rightArm=-a,chest=6 if run else 0)
        return [first, pose(.07 if run else .025,leftShin=b,rightShin=8,chest=8 if run else 2),
                pose(0,leftThigh=a,rightThigh=-a,leftShin=b,rightShin=10,leftArm=-a,rightArm=a,chest=6 if run else 0),
                pose(.07 if run else .025,leftShin=8,rightShin=b,chest=8 if run else 2),first.copy()]
    definitions = [
        ("idle",2.8,True,[0,.25,.5,.75,1],idle,"Quiet weight shift and offset head response."),
        ("walk",1.1,True,[0,.08,.25,.5,.75,.92,1],[gait()[0],*gait(),gait()[-1]],"Illustrative in-place steps; no contact solver."),
        ("run",.65,True,[0,.08,.25,.5,.75,.92,1],[gait(True)[0],*gait(True),gait(True)[-1]],"Faster cycle with forward lean; contact needs refinement."),
        ("jump",1.5,False,[0,.15,.35,.55,.8,1],[pose(),pose(-.12,leftThigh=-22,rightThigh=-22,leftShin=40,rightShin=40,chest=12),pose(.65,leftArm=-65,rightArm=-65),pose(.8,leftThigh=-25,rightThigh=-25,leftShin=45,rightShin=45),pose(-.1,leftShin=20,rightShin=20,chest=10),pose()],"Anticipate, launch, apex, absorb, settle."),
        ("fall",.8,False,[0,.35,.8,1],[pose(.65,leftArm=-45,rightArm=-45),pose(.4,leftShin=20,rightShin=20),pose(-.1,leftShin=20,rightShin=20),pose()],"Airborne start through impact and settle."),
        ("land",.6,False,[0,.2,.55,1],[pose(.12),pose(-.12,leftThigh=-20,rightThigh=-20,leftShin=35,rightShin=35,chest=12),pose(.02,chest=-3),pose()],"Impact compression with delayed recovery."),
        ("turn",1.2,False,[0,.2,.65,1],[pose(),pose(headYaw=18),pose(rootYaw=65,headYaw=12),pose(rootYaw=90)],"Head leads a quarter turn; planted-foot turn needs a separate clip."),
        ("wave",1.8,False,[0,.2,.35,.5,.65,.8,1],[pose(),pose(rightArmZ=145,rightForearmZ=20,head=-5),pose(rightArmZ=145,rightForearmZ=-20),pose(rightArmZ=145,rightForearmZ=25),pose(rightArmZ=145,rightForearmZ=-20),pose(rightArmZ=145,rightForearmZ=10),pose()],"Raise, greet, follow through and return."),
    ]
    clips = []
    for name,duration,loop,beats,poses,description in definitions:
        times = [round(t*duration,6) for t in beats]; tracks=[]
        for bone in bones:
            values=[]
            for p in poses:
                key=bone["name"]; angle=p.get(key,0); axis=0
                if key+"Z" in p: angle=p[key+"Z"]; axis=2
                if key+"Yaw" in p: angle=p[key+"Yaw"]; axis=1
                half=math.radians(angle)/2; q=[0,0,0,math.cos(half)]; q[axis]=math.sin(half); values.append(q)
            tracks.append({"bone":bone["name"],"path":"quaternion","times":times,"values":values})
        tracks.append({"bone":"hips","path":"position","times":times,"values":[[0,1.12+p["height"],0] for p in poses]})
        clips.append({"name":name,"duration":duration,"fps":30,"loop":loop,"description":description,"beats":beats,"tracks":tracks})
    return {"format":"motion-lab/v1","units":"meters, seconds, quaternion xyzw","quality":"Original illustrative poses, not motion capture; foot contact is unvalidated.","bones":bones,"clips":clips}


if __name__ == "__main__":
    p=argparse.ArgumentParser(description=__doc__); p.add_argument("output",type=Path); a=p.parse_args()
    try:
        with a.output.open("x") as f: json.dump(generate(),f,indent=2,allow_nan=False); f.write("\n")
    except OSError as exc: p.exit(1,f"Error: {exc}\n")
