#!/usr/bin/env python3
"""Read-only PNG and glTF/GLB metadata inventory; never fetch external resources."""
import argparse
import hashlib
import json
import struct
from pathlib import Path
from urllib.parse import unquote, urlsplit


def glb_document(raw):
    if len(raw) < 20: raise ValueError("Truncated GLB header")
    magic, version, length = struct.unpack_from("<4sII", raw)
    if magic != b"glTF" or version != 2 or length != len(raw): raise ValueError("Invalid GLB v2 header/length")
    offset, doc = 12, None
    while offset < length:
        if offset + 8 > length: raise ValueError("Truncated chunk header")
        size, kind = struct.unpack_from("<II", raw, offset); offset += 8
        if size % 4 or offset + size > length: raise ValueError("Invalid chunk length")
        if doc is None:
            if kind != 0x4E4F534A: raise ValueError("GLB first chunk must be JSON")
            doc = json.loads(raw[offset:offset+size].decode("utf-8"))
        offset += size
    if not isinstance(doc, dict): raise ValueError("Missing JSON document")
    return doc


def inspect(path):
    path = Path(path)
    raw = path.read_bytes()
    result = {"path": str(path), "bytes": len(raw), "sha256": hashlib.sha256(raw).hexdigest()}
    suffix = path.suffix.lower()
    if suffix == ".png":
        if len(raw) < 33 or raw[:8] != b"\x89PNG\r\n\x1a\n" or raw[12:16] != b"IHDR": raise ValueError("Invalid PNG header")
        width, height, depth, color = struct.unpack_from(">IIBB", raw, 16)
        if not width or not height: raise ValueError("PNG dimensions must be positive")
        result.update(kind="png", width=width, height=height, bit_depth=depth, alpha_channel=color in (4,6), note="Header inspection only; transparency via tRNS and image integrity need a decoder.")
    elif suffix in (".glb", ".gltf"):
        doc = glb_document(raw) if suffix == ".glb" else json.loads(raw)
        if not isinstance(doc, dict) or not isinstance(doc.get("asset"), dict) or doc["asset"].get("version") != "2.0": raise ValueError("Expected glTF 2.0")
        for key in ("nodes", "skins", "animations", "buffers", "images", "meshes"):
            if key in doc and (not isinstance(doc[key], list) or not all(isinstance(x, dict) for x in doc[key])):
                raise ValueError(f"glTF {key} must be an array of objects")
        nodes = doc.get("nodes", [])
        dependencies = []
        for item in doc.get("buffers", []) + doc.get("images", []):
            uri = item.get("uri")
            if not uri: continue
            if not isinstance(uri, str): raise ValueError("glTF resource URI must be a string")
            parsed = urlsplit(uri)
            if parsed.scheme == "data": state = "embedded"
            elif parsed.scheme or parsed.netloc: state = "remote-not-fetched"
            else:
                target = (path.parent / unquote(parsed.path)).resolve()
                if not target.is_relative_to(path.parent.resolve()): state = "outside-asset-directory-not-read"
                else: state = "present" if target.is_file() else "missing"
            dependencies.append({"uri": uri[:200], "status": state})
        result.update(kind="gltf", nodes=[{"index": i, "name": n.get("name"), "children": n.get("children", [])} for i,n in enumerate(nodes)], skins=[{"name": s.get("name"), "joints": s.get("joints", [])} for s in doc.get("skins", [])], animations=[{"name": c.get("name"), "channels": len(c.get("channels", []))} for c in doc.get("animations", [])], meshes=len(doc.get("meshes", [])), dependencies=dependencies, note="Metadata only; use a glTF validator and runtime for buffer, skin and animation validation.")
    else:
        result.update(kind="unparsed", note="Metadata only. Use a format-specific decoder for images, FBX, Spine and video.")
    return result


if __name__ == "__main__":
    p = argparse.ArgumentParser(description=__doc__); p.add_argument("path", type=Path); a = p.parse_args()
    paths = sorted(x for x in a.path.iterdir() if x.is_file()) if a.path.is_dir() else [a.path]
    results, failed = [], False
    for path in paths:
        try: results.append(inspect(path))
        except (OSError, ValueError, TypeError, KeyError, struct.error) as exc:
            results.append({"path": str(path), "error": str(exc)}); failed = True
    print(json.dumps(results, indent=2))
    raise SystemExit(int(failed))
