#!/usr/bin/env python3
"""Copy the tested web example into an absent destination without installing anything."""
import argparse
import shutil
from pathlib import Path


def scaffold(destination):
    destination = Path(destination).expanduser().absolute()
    source = Path(__file__).resolve().parents[1] / "examples" / "motion-lab"
    if destination.exists() or destination.is_symlink():
        raise ValueError(f"Destination already exists: {destination}. Choose a new directory.")
    resolved = destination.resolve()
    if source.resolve() == resolved or source.resolve() in resolved.parents:
        raise ValueError("Destination must be outside the bundled example.")
    shutil.copytree(source, destination, ignore=shutil.ignore_patterns(
        "node_modules", "dist", "test-results", "__pycache__"))
    return destination


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("destination")
    args = parser.parse_args()
    try:
        path = scaffold(args.destination)
    except (ValueError, OSError) as exc:
        parser.exit(1, f"Error: {exc}\n")
    print(f"Created {path}\nNext: cd into that directory, run npm ci, then npm run dev.")
