import copy
import importlib.util
import json
import struct
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'scripts'))
from make_presets import generate
from validate_motion import validate
from inspect_asset import inspect, glb_document
from scaffold import scaffold


class MotionTests(unittest.TestCase):
    def setUp(self): self.data=generate()
    def test_all_eight_presets(self):
        result=validate(self.data)
        self.assertTrue(result['ok'],result)
        self.assertEqual(result['clips'],8)
    def test_bad_hierarchy(self):
        self.data['bones'][0]['parent']='head'
        self.assertFalse(validate(self.data)['ok'])
    def test_duplicate_bone(self):
        self.data['bones'].append(self.data['bones'][0].copy())
        self.assertFalse(validate(self.data)['ok'])
    def test_missing_reference(self):
        self.data['clips'][0]['tracks'][0]['bone']='absent'
        self.assertFalse(validate(self.data)['ok'])
    def test_times_and_nonfinite(self):
        for mutation in ('duplicate','nan','outside'):
            data=copy.deepcopy(self.data); track=data['clips'][0]['tracks'][0]
            if mutation=='duplicate': track['times'][1]=track['times'][0]
            elif mutation=='nan': track['values'][0][0]=float('nan')
            else: track['times'][-1]=100
            self.assertFalse(validate(data)['ok'],mutation)
    def test_bad_quaternion_and_seam(self):
        self.data['clips'][0]['tracks'][0]['values'][-1]=[0,0,1,0]
        self.assertFalse(validate(self.data)['ok'])
    def test_antipodal_is_same_pose(self):
        self.data['clips'][0]['tracks'][0]['values'][-1]=[0,0,0,-1]
        self.assertTrue(validate(self.data)['ok'])
    def test_cli_failure_is_json(self):
        with tempfile.TemporaryDirectory() as directory:
            file=Path(directory)/'bad.json';file.write_text('{broken')
            p=subprocess.run([sys.executable,str(ROOT/'scripts/validate_motion.py'),str(file)],capture_output=True,text=True)
            self.assertEqual(p.returncode,1);self.assertFalse(json.loads(p.stdout)['ok'])


class AssetTests(unittest.TestCase):
    def test_glb_and_truncation(self):
        payload=json.dumps({'asset':{'version':'2.0'},'nodes':[{'name':'hips'}]}).encode();payload+=b' '*((-len(payload))%4)
        raw=struct.pack('<4sII',b'glTF',2,20+len(payload))+struct.pack('<II',len(payload),0x4e4f534a)+payload
        self.assertEqual(glb_document(raw)['nodes'][0]['name'],'hips')
        with self.assertRaises(ValueError):glb_document(raw[:-1])
    def test_png_and_mixed_batch(self):
        with tempfile.TemporaryDirectory() as d:
            path=Path(d)
            # Header fixture only; inspector explicitly does not claim decoder validation.
            png=b'\x89PNG\r\n\x1a\n'+struct.pack('>I',13)+b'IHDR'+struct.pack('>IIBBBBB',32,64,8,6,0,0,0)+b'\x00'*4
            (path/'part.png').write_bytes(png)
            self.assertEqual(inspect(path/'part.png')['height'],64)
            (path/'bad.gltf').write_text('{"asset":null}')
            p=subprocess.run([sys.executable,str(ROOT/'scripts/inspect_asset.py'),d],capture_output=True,text=True)
            self.assertEqual(p.returncode,1);result=json.loads(p.stdout)
            self.assertEqual(len(result),2);self.assertTrue(any(x.get('kind')=='png' for x in result))
    def test_external_dependency_not_fetched(self):
        with tempfile.TemporaryDirectory() as d:
            file=Path(d)/'model.gltf';file.write_text(json.dumps({'asset':{'version':'2.0'},'buffers':[{'uri':'../private.bin'},{'uri':'https://example.com/a.bin'}]}))
            states=[x['status'] for x in inspect(file)['dependencies']]
            self.assertEqual(states,['outside-asset-directory-not-read','remote-not-fetched'])


class ScaffoldTests(unittest.TestCase):
    def test_create_and_refuse_overwrite(self):
        with tempfile.TemporaryDirectory() as d:
            dest=Path(d)/'app';scaffold(dest)
            self.assertTrue((dest/'src/motion.json').exists());self.assertFalse((dest/'node_modules').exists())
            (dest/'keep.txt').write_text('user content')
            with self.assertRaises(ValueError):scaffold(dest)
            self.assertEqual((dest/'keep.txt').read_text(),'user content')
    def test_symlink_containment(self):
        with tempfile.TemporaryDirectory() as d:
            alias=Path(d)/'alias';alias.symlink_to(ROOT/'examples/motion-lab',target_is_directory=True)
            with self.assertRaises(ValueError):scaffold(alias/'must-not-create')


if __name__=='__main__':unittest.main()
