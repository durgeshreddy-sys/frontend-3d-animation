# Camera choreography

Author shots as data: progress window, position, target, FOV, subject, UI hold and easing. Plan portrait framing with desktop; macro details must leave room for product copy.

Use native scroll and sticky sections first. Progress is `clamp(-rect.top / (sectionHeight - viewportHeight), 0, 1)` with a safe zero-denominator branch. Do not consume the whole page's wheel events. If using a scroll library, one clock owns progress and teardown removes its listeners.

Interpolate authored camera positions and slerp orientations or smoothly move a look-at target. Prevent camera/target crossings, floor penetration and clipping. Fixed-up `lookAt` needs care near poles. One camera owner arbitrates intro, scroll and manual views.

Segment interpolation with smoothstep is a robust starting point: it preserves holds, bounds and explicit reverse segments but stops velocity at each key pose. Use a tangent-continuous curve for uninterrupted travel. Reject duplicate progress coordinates. Sample curves to catch overshoot and undeclared reversals.

NAÏADE has a deliberate rewind despite forward-only prose. Enforce direction per segment. Use `1-exp(-lambda*dt)` for frame-rate-independent lag only when desired; drive cards and camera from the same smoothed progress. Rapid reversal must settle on the latest target.

Mobile: shorter travel, larger subject, cards below or beside it, intact touch scrolling. Reduced motion: fixed shot with normal content flow, no giant empty pinned region. Shot buttons may switch instantly.

If using image sequences instead, budget decoded memory as `width * height * 4 * cachedFrames`, cap decode concurrency, cancel stale work, keep a bounded bitmap cache and supply a poster. This remains prerecorded media, not a true 3D camera.
