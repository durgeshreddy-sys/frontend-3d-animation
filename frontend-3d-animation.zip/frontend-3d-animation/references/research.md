# Research report

Prepared 2026-11-26. The current request makes the web stack primary; the master brief contributes asset, motion and QA requirements. See [requirement matrix](prompt-analysis.md) for every named frontend example and the screenshot tool list.

## Evidence and coverage

The public Spine repository was cloned read-only for analysis at commit `702b71689cac826efee942ee4564fef9560d6ef8`. Review covered the repository tree, Python module/function inventory, the five core scripts, SKILL/template structure, example skeleton/atlas layout and selected reskin application modules. This is implementation research, not a claim that every application path was executed or every example asset visually validated. No upstream source or artwork is included in this skill.

The source repository has an important license boundary: its LICENSE identifies PolyForm Noncommercial 1.0.0. Treat it as reference material rather than an automatically reusable commercial dependency. [Repository license](https://github.com/GenielabsOpenSource/spine-animation-ai/blob/702b71689cac826efee942ee4564fef9560d6ef8/LICENSE).

## Repository architecture

`SKILL.template.md` contains workflow prose and script embedding markers. `build_skill.py` expands the script files into the generated SKILL. The main pipeline is full-image generation/segmentation (optional) → part matching → explicit skeleton config → preset/custom animation → texture atlas → official-player preview. The supplied example is a cutout character, not a 3D skinned model. [Template](https://github.com/GenielabsOpenSource/spine-animation-ai/blob/702b71689cac826efee942ee4564fef9560d6ef8/SKILL.template.md).

The separate `reskin-app` is a React frontend and Python backend for opening projects, snapshotting, per-slot editing, generation, atlas rebaking and exporting skins. Its AI-provider boundary, project parsing and logging are separate from the simple script pipeline. The atlas path combines a rendered reference and atlas; the exploded path composes separated parts. Segmentation/rebaking happens later. That separation is useful: analysis, generation and export should not be one opaque operation. [Pipeline](https://github.com/GenielabsOpenSource/spine-animation-ai/blob/702b71689cac826efee942ee4564fef9560d6ef8/reskin-app/app/backend/reskin/pipeline.py).

## Algorithms and observed limitations

| Component | Findings and transfer decision |
|---|---|
| `split_character.py` | Uses an image-generation provider before connected-component segmentation. It creates a new parts sheet rather than reliably extracting hidden limbs. Thresholding can discard bright details. The documented package name and `google.genai` import need reconciliation before use. Keep external generation optional and disclose identity risk. |
| `position_parts.py` | Alpha-masked SIFT, FLANN ratio filtering and RANSAC. Despite homography labels, implementation uses `estimateAffinePartial2D` (similarity-like transform). Template fallback handles low-feature parts. Rotations/scales are constrained. The draw-order implementation sorts weighted pairwise votes rather than topologically sorting an occlusion graph. Reuse the confidence/correction workflow, not unsupported certainty. |
| `build_spine_json.py` | Accepts an explicit hierarchy and recognized bone names, then emits preset/custom curves. This is not automatic anatomical rigging. Contains 4.2 wire-format conversion, including per-property curve controls. Unknown/missing preset joints can silently reduce motion. Validate coverage, hierarchy and format separately. |
| `make_atlas.py` | Height-sorted row packing, power-of-two canvas, padding and atlas metadata. Simple and reproducible, but no maximum GPU texture budget or sophisticated packing/extrusion. Check filter bleed and oversized output before runtime use. |
| `generate_spine_player.py` | Embeds data assets and references an official player from a CDN. Embedded assets do not make the player fully offline. Verify runtime version, dependencies and license rather than claiming standalone compatibility from HTML generation. |
| Reskin segmentation | Connected components can be matched by silhouette IoU after background removal; low match scores need review. A SAM stub also exists alongside a separate provider implementation; do not mistake presence of a module for a fully configured service. |

Source implementations: [split](https://github.com/GenielabsOpenSource/spine-animation-ai/blob/702b71689cac826efee942ee4564fef9560d6ef8/scripts/split_character.py), [position](https://github.com/GenielabsOpenSource/spine-animation-ai/blob/702b71689cac826efee942ee4564fef9560d6ef8/scripts/position_parts.py), [builder](https://github.com/GenielabsOpenSource/spine-animation-ai/blob/702b71689cac826efee942ee4564fef9560d6ef8/scripts/build_spine_json.py), [atlas](https://github.com/GenielabsOpenSource/spine-animation-ai/blob/702b71689cac826efee942ee4564fef9560d6ef8/scripts/make_atlas.py), [player](https://github.com/GenielabsOpenSource/spine-animation-ai/blob/702b71689cac826efee942ee4564fef9560d6ef8/scripts/generate_spine_player.py), [component segmentation](https://github.com/GenielabsOpenSource/spine-animation-ai/blob/702b71689cac826efee942ee4564fef9560d6ef8/reskin-app/app/backend/ai/cc_segment.py).

A narrow executable check of the builder supplied one custom rotate key `{time:0, angle:30}`. The output still contained `angle`, because conversion returns early for timelines shorter than two keys, despite declaring 4.2. This demonstrates a conversion edge case; it is not a claim of a full official-runtime test. Another inspection concern: debug-match tuple unpacking assumes two neighbors before checking their length. These findings support stronger malformed-input tests in the new tools.

## Mixamo and quality

Adobe documents the web workflow; the Mixamo library page did not expose readable motion entries to this research client. No authenticated motion download or frame-by-frame motion analysis was performed. The skill therefore provides a motion-only intake/retargeting procedure rather than claiming to ship Mixamo clips. Never download Mixamo characters for this task. [Adobe guide](https://helpx.adobe.com/creative-cloud/help/mixamo-rigging-animation.html), [Mixamo library](https://www.mixamo.com/).

The procedural fixture uses deliberately authored action phases and named joint tracks. It is appropriate for testing hierarchy, time controls and export. Realistic locomotion needs contact-aware trajectories and target proportions; the advanced recipes and twelve-principle review live in [motion quality](motion-quality.md).

## Proposed and delivered architecture

The reusable system separates brief analysis, assets, scene construction, input, camera, character playback, export and QA. React/Tailwind owns user-facing behavior; Fiber/Three owns the scene; Python performs deterministic offline inspection and structural checks. Optional Blender/Spine/provider workflows are invoked only when relevant and available. [Architecture](architecture.md) defines inputs, outputs and failure paths.

The local installed skill-creator instructions were the primary convention reference; official skill documentation was also checked. The package uses a short YAML-frontmatter SKILL, separate references/scripts/examples/tests and `agents/openai.yaml`, with normal implicit invocation. [Official skill documentation](https://developers.openai.com/codex/skills/).

No user decision was necessary to build this package. A future production scene needs the actual character/model, desired aesthetic, permitted asset sources and target device constraints. Those inputs must not be fabricated from the fictional reference brands.
