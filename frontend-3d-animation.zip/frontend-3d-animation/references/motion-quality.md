# Motion quality and preset authoring

The example's original key poses are illustrative, not motion capture or professionally finished locomotion. It has no ground-contact solver. Use supplied character proportions and contact evidence to refine motion.

| Principle | Observable review |
|---|---|
| Squash/stretch | Preserve approximate volume; do not lengthen rigid bones inadvertently |
| Anticipation | Weight shifts or compression precede the main action |
| Staging | Silhouette and camera make the action readable |
| Straight-ahead / pose-to-pose | Block key poses first; integrate secondary motion continuously |
| Follow-through / overlap | Head, hands and accessories settle after the torso |
| Slow in / out | Timing reflects intent; avoid easing a planted foot into sliding |
| Arcs | Track hands/feet through space, not just independent axis curves |
| Secondary action | Supports the main movement without competing with it |
| Timing | Contact, action and recovery have deliberate durations |
| Exaggeration | Increase readable action without breaking identity or joints |
| Solid form | Preserve balance, volumes and plausible joint behavior |
| Appeal | Inspect expression, asymmetry and clear silhouettes |

Loop validation needs pose continuity and velocity continuity. Quaternion q and -q describe the same rotation; compare angular distance using absolute dot product. For velocity, compare small samples on both sides of the wrap. A matching first/last frame alone does not prove smoothness.

Foot sliding: identify contact intervals from known events or conservative height/velocity thresholds, then compute each contacting foot's world-space horizontal travel. Report distance and speed relative to character height, separating intended skating, moving platforms and in-place previews. Without contact labels/world transforms, mark it unmeasured. The bundled validator does exactly that.

Inspect balance using the projected center of mass and support area where the action permits it. For a jump, verify takeoff impulse, airborne arc, impact absorption and delayed recovery. A sinusoidal bob is not a substitute for these phases.

## Preset contract

Every clip records name, duration, authoring FPS, loop flag, key-pose times, bone transformations, description and review notes. The bundled `motion-lab/v1` data uses meters, seconds and xyzw quaternions. Tracks span 0 to duration. Its linear interpolation is deliberate and should be refined for final character work; FPS is authoring metadata, not a forced browser rendering rate.

The eight generated basic presets are idle, walk, run, jump, fall, land, turn and wave. Rebuild with `make_presets.py` into a new file; do not overwrite user-authored edits. Advanced actions are recipes requiring new poses or licensed clips:

| Action | Essential phases and checks |
|---|---|
| Sprint | Lean, compressed contact, flight, recovery; stride speed matches root travel |
| Sneak | Lowered center, careful toe placement, extended support; no foot drift |
| Crouch | Hip/knee flexion, balanced hold, return; foot position stable |
| Sit / stand | Approach/support transfer, seat contact, settle / forward weight transfer then rise |
| Dance | Beat accents and repeating phrase; preserve intended asymmetry |
| Fight / punch / kick | Guard, anticipation, strike, recovery; joint limits and support leg |
| Dodge / roll | Directional anticipation, displacement, protection, regain balance |
| Climb | Ordered hand/foot contacts and pull; grip stays at the surface |
| Celebrate | Main gesture, overlapping secondary reaction, readable settle |
| React / gesture | Trigger, attention shift, expression/body response, neutral recovery |

Never silently substitute a generic humanoid gait for a nonhuman creature. Record untested joints and visual defects instead of calling export success “production quality.”
