# Runtime architecture

For a new small project use Vite, React, Three.js, R3F and Tailwind. Check package manifests and peer dependencies first. React 19 pairs with Fiber 9; React 18 with Fiber 8. [R3F documentation](https://r3f.docs.pmnd.rs/getting-started/introduction).

Tailwind 4's Vite path uses `@tailwindcss/vite` and `@import "tailwindcss"`. Keep full static class names and CSS variables for continuously changing values; do not mix v3 setup instructions into v4. [Tailwind installation](https://tailwindcss.com/docs/installation/using-vite).

```text
DOM shell: copy, controls, fallback, error state
  discrete state: selection, mode, paused, quality
  Canvas
    camera director -> camera / target / FOV
    actor rig -> clip mixer -> optional secondary offsets
    input surface -> local target -> spring -> uniforms
    lighting + floor + optional effects
```

| Module | Inputs → outputs | Validation / failure |
|---|---|---|
| Brief analysis | refs/assets → scene plan | Separate footage from geometry |
| Asset inspection | files → dimensions/nodes/skins/clips | Read-only, no remote fetch, report parse failure |
| Scene builder | models/materials → scene graph | Suspense, boundary, static fallback |
| Motion compiler | canonical rig + JSON → Three clips | Unknown bones and bad timing rejected |
| Interaction | input → bounded local targets | Cancel/release/blur; non-drag equivalent |
| Camera | section progress → shot | Single owner and safe path |
| Quality | measured cost → DPR/effects/LOD | Hysteresis; avoid oscillating quality |
| Export | neutral rig + clips → GLB | Reimport; shaders do not serialize |
| QA | structural/browser evidence → report | Separate passes from unmeasured quality |

These roles do not require a class or service per row. Start with components and pure functions.

Frame updates belong in refs and `useFrame`, with seconds-based delta and scratch objects. One owner updates each mixer. For static/paused scenes use demand rendering; invalidate until springs/transitions settle. Continuous animation requires continuous rendering. [R3F performance guidance](https://r3f.docs.pmnd.rs/advanced/pitfalls).

Use a clear key/fill relationship and floor contact before adding bloom. Color textures and linear mask/normal/roughness data need correct color spaces. Verify the installed renderer's color pipeline. Deformation needs appropriate normals and matching shadow deformation. Keep DOM typography readable across actual frames.

For SSR, mount Canvas client-side while leaving the shell renderable on the server. Clone skeletons for independent actors; do not share mutable joints. Dispose owned resources, preserving shared cached assets.

Starting budget, not a guarantee: mobile DPR 1–1.5, one shadow light, modest textures, optional postprocessing. Record device, frame time, draw calls and texture memory. Reduce effects/shadows before lowering essential geometry detail.
