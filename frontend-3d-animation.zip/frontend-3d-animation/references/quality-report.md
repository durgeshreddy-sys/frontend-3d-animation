# Package quality report

Validated 2026-11-26 in the supplied Linux/WSL workspace. This report describes the delivered skill and its original sample, not an arbitrary future user asset.

## Executed checks

| Check | Result | Evidence / scope |
|---|---|---|
| Skill metadata and scaffold validation | Pass | Skill-creator `quick_validate.py` |
| Python tests | Pass, 13 tests | `python3 -m unittest discover -s tests -v`: hierarchy, times, finite values, quaternion/seam checks, GLB truncation, PNG metadata, batch failure, safe scaffolding |
| Motion data validator | Pass | 12 bones, eight clips; no structural failures; explicit warning that contact/visual quality is unmeasured |
| JavaScript tests | Pass, five tests | `node --test --test-isolation=none tests/motion.test.mjs`: spring/damping frame independence, camera holds/rewind, actual joint binding, finite pose matrices and action phases |
| Production build | Pass | Vite production build; approximately 1.18 MB minified JS / 327 KB gzip; default large-chunk warning remains |
| UI static audit | Pass | Frontend-design-premium strict audit: zero findings; native speed select ownership explicitly recorded |
| Chromium browser suite | Pass | All eight selections, pause/play, one-shot completion/replay, speed, seek, bones, keyboard nudge and pointer release/cancel |
| Export | Pass | JSON download and binary GLB download; GLTFLoader reimport preserved all eight names, positive durations and the head node |
| Responsive and motion preferences | Pass in emulation | 1440×1000 desktop and 390×844 mobile; no horizontal overflow; live reduced-motion change pauses/disables stretch |
| Renderer resilience | Pass in simulation | Dispatched context loss and separately disabled WebGL contexts; DOM content/static poster remain |
| Visual inspection | Pass for demonstration framing/layout | Desktop, mobile and airborne jump screenshots inspected; no final photorealism or gait-contact claim |
| Independent forward testing | Pass after fixes | Separate agent exercised valid/malformed inputs and scaffolding in isolated `/tmp` workspace |

Browser execution used existing Chromium with software rendering and Playwright. The latest run used `PREVIEW_URL=http://127.0.0.1:5174` and a local `BROWSER_PATH`; those environment paths are not required by the distributed skill. The example's ordinary default URL is port 5173.

Tested package resolution: Node 24.22.3, React/React DOM 19.3.1, Fiber 9.8.2, Three 0.180.0, Vite 6.4.6, Tailwind/@tailwindcss/vite 4.3.5, @vitejs/plugin-react 4.7.0, Playwright 1.65.1. The lockfile preserves this resolution; these are tested versions, not a blanket claim that they are current or appropriate for every project.

## Fixes made during validation

- Malformed nested glTF fields now produce per-file errors rather than aborting a whole batch.
- Scaffold containment resolves symlink paths while still refusing existing destinations.
- Walk/run endpoint holds remove the detected linear position-velocity discontinuity at their loop boundary; full gait quality remains unmeasured.
- One-shot playback pauses on completion and can restart through Play.
- Camera framing includes the airborne character's ears.
- Reduced-motion browser assertions wait for the actual preference event.
- Vite polling handles change detection on the mounted filesystem.

## Limits and explicitly unexecuted work

- PNG tests inspect headers; they do not decode a full image, segment body parts or validate PNG CRC/pixel data. Full character reconstruction and sprite-part auto-rigging were not performed.
- The generated mascot is an articulated primitive hierarchy, not weighted skinning. Walk/run are illustrative poses without IK or measured foot contact. No professional-motion certification is claimed.
- Advanced motion recipes are guidance, not an additional library of exported finished clips.
- No user GLB/FBX, authenticated Mixamo export, Blender retargeting or official Spine runtime round-trip was available/tested. The Spine route remains optional guidance.
- Browser tests simulate pointer/cancel and reduced motion; real multi-touch hardware, Safari, Firefox, physical mobile GPU performance, 200% zoom and screen-reader behavior were not comprehensively tested.
- The bundled elastic interaction is head squash/stretch from one drag control, not a four-finger Gaussian face implementation. Shader and scroll-camera workflows are detailed references; the math is tested, but those full scenes are not bundled demos.
- The fourteen screenshot repositories were checked as tool choices; no claim is made that all are installed, mutually compatible, free for every use, or integrated into this starter. “Muse” was not uniquely identified.
- `co` is not installed in this environment. The benchmark rubric was written before skill implementation and is bundled in `tests/behavioral-cases.yaml`; no `co eval` execution or schema compatibility is claimed.

## Preview evidence

- [Desktop](../assets/preview-desktop.png)
- [Mobile with bones](../assets/preview-mobile.png)
- [Airborne jump](../assets/preview-jump.png)

The [source inventory](source-inventory.json) records attachment hashes and section locations without redistributing their full prompt/source contents.
