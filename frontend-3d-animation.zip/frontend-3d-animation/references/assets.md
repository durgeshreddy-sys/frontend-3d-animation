# Asset workflow

Run `inspect_asset.py` on a file or flat asset directory. It reports size/hash, PNG header dimensions, glTF nodes/skins/clip names and dependency presence. It does not modify inputs, follow remote URLs or decode every format. For unknown formats it reports `unparsed`, not an invented successful analysis.

| Input | Useful route | Missing information |
|---|---|---|
| Transparent body parts | Review assembled reference, pivots and overlap; use cutout rig or textured planes | Correct joint placements and draw order cannot be inferred from filenames alone |
| Full character image | Textured plane, landmark deformation, or explicitly chosen segmentation/modeling route | Occluded body parts, geometry and weights |
| Sprite sheet | Supply frame rectangles/padding or atlas metadata; inspect frame order | One image does not identify every frame/pivot reliably |
| GLB/glTF | Load with GLTFLoader; inspect skeleton, clips, morphs, units and materials | Metadata inventory does not validate binary buffers/weights |
| FBX motion | Blender/FBXLoader with explicit unit/axis and rest-pose checks | Motion-only status and compatible target mapping |
| Spine JSON + atlas + textures | Matching official runtime; see Spine bridge | `.spine` editor projects require the editor/export route |

Use Pillow/OpenCV in an isolated environment only when image decoding, masks or matching are actually required. For separated transparent shapes, connected components can isolate disconnected pieces, but cannot separate overlapping limbs reliably. SIFT matching needs image features and a matching assembled reference; blank cartoon areas need landmarks or manual correction. Thresholding a white background may erase white costume details.

Asset manifest fields: id, local path, origin, usage permission/status, hash, dimensions, color space, alpha convention, role, compression, fallback, model units, required decoder. Do not guess redistribution rights. Keep source originals separate from optimized derivatives. Do not embed untrusted filenames into HTML or shell strings.

Optimize after visual validation: resize color textures appropriately, preserve normal map quality, use supported glTF compression only with its decoder configured, and test alpha fringes. Apply model-scale correction at a deliberate root and avoid destroying bind-pose transforms.
