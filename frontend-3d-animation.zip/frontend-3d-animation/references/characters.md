# Character pipeline

## Intake and rig

For GLB/glTF, inventory nodes, skins, joint names, animations, morph targets, bounds, units, forward/up axes and external dependencies. The Python inspector reads metadata; it does not decode binary accessors or validate weights. Load the file in Three GLTFLoader and inspect the neutral pose before adding motion. Preserve originals.

The bundled rig is twelve named Three Bones with rigid primitive meshes attached. It demonstrates hierarchy and clip playback, not smooth weighted skinning. For a supplied SkinnedMesh, check bind matrices, normalized weights, bone inverses, seams and deformation under extreme poses. Clone an actor's skeleton for independent playback; use the installed Three `SkeletonUtils.clone` implementation, not a generic Object3D clone alone.

## Playback and transitions

Make clips from the actual joint bindings. Three quaternions are xyzw and times are seconds. Use quaternion interpolation, not Euler interpolation across ±180°. Keep root movement separate from in-place limb motion. One mixer owns each independent actor; use delta time and stop/uncache actions when the actor is disposed. [AnimationMixer API](https://threejs.org/docs/pages/AnimationMixer.html).

Looping idles/walks use repeat; one-shots use LoopOnce and an explicit policy for returning to idle or holding the end. Match foot phase before crossfading locomotion. Fade weights over a short deliberate interval and stop the previous action after completion. If several controllers affect a joint, use an authored additive layer or apply secondary offsets after the mixer, restoring baseline each frame to avoid accumulation. The bundled example switches immediately for clear pose inspection; it does not claim gait blending.

## Mixamo motion only

Use the user's own character. When available in the authenticated UI, obtain animation-only FBX without skin; confirm the downloaded file actually contains motion and skeleton but no unwanted Mixamo mesh/textures. The public site requires interactive access and supplies no verified public automation API here. Do not bypass access restrictions. [Adobe workflow](https://helpx.adobe.com/creative-cloud/help/mixamo-rigging-animation.html), [Mixamo](https://www.mixamo.com/).

Retargeting requires more than renaming joints:

1. Record source and target rest-pose local/world matrices, orientation and units. Map hips, spine, head and limb chains by meaning. Missing fingers, tails or nonhuman joints need an explicit policy.
2. Align T/A poses and root bases. Derive rotation deltas relative to source rest pose, transform them into the target joint basis, and compose with target rest pose. Verify multiplication order in the selected library using a single-joint fixture.
3. Scale root displacement using appropriate body measurements; preserve horizontal travel or deliberately convert to in-place motion. Do not scale every local translation blindly.
4. Bake to the target rig at a declared rate; inspect wrists, elbows, knees and foot trajectories. Then reduce keys within an error tolerance.
5. Correct contact with an actual contact/IK process if needed. Do not claim Mixamo or a humanoid mapping produces reliable quadruped motion.

Prefer Blender or a verified retargeting implementation when skeletons differ substantially. Inspect installed `SkeletonUtils.retargetClip` options before relying on them. Keep the output in a new GLB, test it with GLTFLoader and inspect multiple poses.

## Export and comparison

Export from the neutral setup pose with clips explicitly included. Reimport to check transforms, names, duration and pose samples. Custom shaders, spring controllers and browser interaction do not automatically become glTF animation. [GLTFExporter API](https://threejs.org/docs/pages/GLTFExporter.html).

For original/refined comparison, instantiate independent rigs, use one explicit time signal and camera, and display both at matching scale. Overlay foot trajectories/contact intervals and sample the same poses. Do not compare clips at unrelated time offsets.
