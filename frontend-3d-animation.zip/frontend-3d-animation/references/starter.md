# Starter and commands

From the skill directory:

```bash
python3 scripts/scaffold.py /absolute/path/to/new-motion-project
cd /absolute/path/to/new-motion-project
npm ci
npm run dev
```

Use a current Node release satisfying the package engines (tested here with Node 24). The lockfile records the tested dependency resolution. `npm run build` creates a production build; `npm test` runs mathematical/clip checks. `npm run test:browser` requires the dev server and a Playwright Chromium installation. Set `BROWSER_PATH` if using an existing Chromium executable and `PREVIEW_URL` if the server has another port. Nothing publishes automatically.

The example includes an original articulated 3D mascot, eight named key-pose clips, pause/play, speed, scrubber, visible keyframe markers, skeleton overlay and head squash/stretch. Pointer drag is a single-pointer, vertical stretch control; keyboard activation produces the equivalent nudge. It is not the full multi-touch Otis face shader.

Reduced motion starts paused, disables stretch and reacts to preference changes. The user may deliberately play clips. Hidden tabs stop animation. Renderer failure leaves the static original SVG and data/model downloads. The UI has no backend or external asset fetches.

Export model creates a neutral articulated GLB with eight clips. It is not a weighted SkinnedMesh, and interactive head stretch is not baked into export. Save motion data exports the clearly named custom `motion-lab/v1` authoring format.

## Adaptation examples

“Use $frontend-3d-animation to build a React/Tailwind hero around my GLB product, with three scroll camera shots and a static mobile fallback.”

“Use $frontend-3d-animation to adapt the Otis interaction to an R3F textured plane, preserving my portrait and supporting pointer cancellation and a keyboard reaction.”

“Use $frontend-3d-animation to inspect my character GLB, play its existing clips, and add phase-matched walk/run transitions. Report missing rig data before retargeting.”

“Use $frontend-3d-animation to make an easylog-style UV paint reveal on my mesh. Keep the heading and CTA usable without WebGL.”

## Schema boundary

The Python validator supports the bundled custom format only: a named parent tree, local rest positions, named clips, positive duration/FPS, boolean loop and tracks with bone/path/times/vector values. Supported paths are position, scale and quaternion. Track times strictly increase and span the entire clip. Quaternion values are normalized xyzw. Extra descriptive metadata is allowed. It does not validate arbitrary glTF or Spine animation JSON.
