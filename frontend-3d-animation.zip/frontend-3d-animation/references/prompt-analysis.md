# Requirement consolidation

The latest request selects React JS, Three.js, React Three Fiber and Tailwind for a reusable frontend animation skill. The attachments contain thirteen website briefs and a broader character-animation specification. Brand copy, exact pixel values and original library bans belong to the particular source reproductions.

| Brief | Actual mechanism | Transfer into the requested stack |
|---|---|---|
| easylog | Canvas 2D, bare/moss image compositing, cursor mask, pixel intro | UV paint mask, time-based decay, decode before reveal; real wood needs geometry/UVs |
| lucid | Fog erase, path-following hand, night/day stills, tiles | Shared mask coordinates, scene lighting transitions; stills are not a 3D field |
| VESTRA | Registered garment plates, flying packshot, queued swap | Variant transitions, alignment, queued intent; true fitting needs compatible garments |
| Novu | Fox video decoded to frames and scroll-scrubbed | Bounded caches and synchronized progress; real orbit needs fox GLB and motion |
| Blendy | Cutouts, directional wipe, measured coverage, depth offsets | Bottle mesh and fruit layers with differing timing; keep live DOM type |
| Stratum | Video chapters, text decode and restrained parallax | Last selection wins, cancel stale loads, reserve label widths |
| Otis | WebGL2 portrait grid, four Gaussian grabs, spring, expression images | R3F plane shader or actual head geometry; shared UV landmarks and bounded pulls |
| SELENE | Layered lunar imagery, Earthrise, SVG capsule trajectory | Horizon occlusion, sphere Earth, authored path and section progress |
| NAÏADE | Frame sequence, camera holds, focal cropping and rewind | Shot data, camera/card coordination, explicit reverse segment and portrait framing |
| Glacier | Cinematic video and centered exhibition typography | Strong hierarchy and restrained UI; optional real ice scene |
| Fluxora | AR video, warm scrims, CSS reveals | Lighting-aware contrast and deliberate reveal timing |
| Visor | Video/model occlusion of live text, angled cards, modals | Foreground/DOM layers; semantic text and proper dialog focus |
| Monsoon | Bright mist video, dark top copy, light lower sponsors | Contrast by actual image region, optional volumetric landscape |

## Requirement matrix

| Requirement | Priority | Resolution / evidence |
|---|---|---|
| Requested web stack | Core | Runnable `examples/motion-lab`, scaffold and architecture |
| Analyze before coding | Core | This matrix, research and prewritten `.co/benchmarks` rubric |
| Modular Codex skill | Core | SKILL, references, Python tools, examples, tests and README |
| Literal source / no substitutions | Conflicts with latest request | Preserve for exact-reproduction mode; this delivery adapts the patterns |
| Wait for further prompts | Superseded for this delivery | Latest explicit request asks to make the skill using the supplied material |
| Preserve character identity | Core | Asset/rest-pose review; no silent replacement art |
| Parts, full image, sheet, rig and clip intake | Core | Metadata inspection and documented routes; missing geometry remains explicit |
| Automatic part detection/reconstruction | Optional asset-authoring | Feasibility and limitations documented; no universal generator claimed |
| Skeleton and hierarchy | Core character route | Original Three Bone hierarchy and fixture |
| Idle/walk/run/jump/fall/land/turn/wave | Core demonstrations | Eight authored key-pose presets and Three clip playback |
| Advanced motions | Extension recipes | Sprint, sneak, crouch, sit/stand, dance, fight, punch/kick, dodge/roll, climb, celebrate/react/gesture |
| Mixamo animation only | Hard constraint | Documented motion-only route; no Mixamo characters downloaded |
| Animation principles | Quality framework | Observable review criteria, contact and transition guidance |
| Interactive preview and export | Core demo | Selection, pause, speed, seek, bones, JSON and GLB export |
| Compare original/refined motion | Conditional workflow | Synchronized duplicate actors described; no full editor claimed |
| Versioned Spine export | Optional separate pipeline | Investigated and documented; no untested exporter bundled |
| Hierarchy/timeline/loop QA | Core | Python validator, Node math/clip tests, browser checks |
| Foot sliding and production finish | Asset-dependent | Explicitly unmeasured unless contact/world-transform analysis is performed |
| No unnecessary dependencies | Core | Python stdlib; web stack plus dev-only testing tools |
| README, install/use, tests, report | Explicit deliverables | Included as requested by the master brief |
| New screenshot: 14-repository studio | Supporting reference | Tool-selection matrix; not fourteen mandatory runtime packages |

## Conflicts and missing inputs

The sources mix vanilla HTML, raw WebGL, CSS modules, Tailwind and several animation libraries. Transfer behavior rather than installing their union. “Do not add files” applies to exact page copies, not this skill's tests and references.

NAÏADE claims forward-only time in prose but explicitly rewinds in `BEATS`. Enforce direction per phase, not globally. Reduced-motion policies disagree about autoplay; default to no unsolicited motion. Hosting instructions differ per asset; retain provenance and follow the chosen asset's permissions. Download, decode and visual intro completion are distinct states.

2D cutout rigging, textured-plane deformation and 3D skinning require different data and exports. The attachments do not supply a user-owned GLB, rest pose, licensed animation-only FBX or target hardware. An original primitive mascot makes the example independently runnable. Real user characters require those future inputs.
