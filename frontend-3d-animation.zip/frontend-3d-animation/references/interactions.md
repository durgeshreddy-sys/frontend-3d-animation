# Elastic surfaces and paint masks

Use a textured plane to preserve a portrait; use a real head only when geometry exists. A plane cannot reveal a real side profile. Start with enough subdivisions to keep the stretched outline smooth, and measure cost. Otis uses 128×128 cells and four grab slots; these are reference values, not universal requirements.

```text
w = exp(-dot(restPosition-anchor, restPosition-anchor)/(2*sigma*sigma))
deformed = restPosition + sum(w * pull)
boundedPull = normalize(rawPull) * limit * tanh(length(rawPull)/limit)
acceleration = -stiffness * offset - damping * velocity
```

Use bounded substeps or a closed-form spring, not unrestricted frame deltas. The example supplies an exact underdamped spring step. Discard long hidden-tab gaps.

Convert client pixels → canvas rect → NDC → interaction plane → mesh local coordinates. Keep image UV y and DOM y conventions explicit. Share landmarks for hits, expression zones and color masks. Recheck after resize, scroll and camera movement. GPU vertex displacement does not update CPU raycasting: use a deliberate hit proxy or displaced picking. Expand bounds or disable culling for large deformation.

Capture pointer IDs on a DOM hit surface; release on up, cancel, lost capture and window blur. Keep bounded slots for multiple pointers rather than assuming R3F multi-pointer capture works in every version. Restrict `touch-action: none` to the manipulation area. Supply a keyboard/button action for the same effect.

Portrait hits need a cached alpha mask, not rectangular grabbing. Handle CORS before pixel reads. Registered expression textures must share crop, size and landmarks. Use neutral → grab expression → release reaction → idle states, elapsed hold time and stale-load cancellation. Keep DOM copy clickable.

For easylog/lucid, maintain a low-resolution UV mask, interpolate brush samples and decay with `exp(-rate*dt)`. CanvasTexture is often sufficient; use ping-pong render targets for heavier paint effects. Never sample from the target currently being written. Masks are linear data. Preserve rest UVs and plan for UV seams on actual geometry.

A decorative hand wipe is separate from measured load progress. Reduced motion skips the intro and keeps user-triggered instant states. Custom shader behavior cannot be exported as glTF animation; bake geometry/morph targets or deliver source alongside the model.
