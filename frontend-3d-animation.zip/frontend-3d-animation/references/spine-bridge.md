# Optional Spine bridge

Spine is a separate 2D cutout/skinning format, not an alternative extension for Three animation JSON. This package does not ship a Spine exporter or claim runtime compatibility for generated files.

For existing Spine assets, record export version, skeleton JSON/binary, atlas and all page textures. Match major/minor editor and runtime versions; patch numbers may differ. Test in the official runtime. [Spine versioning](https://esotericsoftware.com/spine-versioning).

For new cutouts: preserve original parts; review pivots, hierarchy and draw order against an assembled reference; reconstruct hidden areas only with explicit creative intent. Validate parent references/cycles, slots/bones, skin attachments, atlas regions/page sizes, timeline ordering and expected duration. Use the target format's actual property names and curve semantics. JSON parsing alone is insufficient.

The reviewed upstream targets 4.2, converts rotation shorthand and per-property Bezier controls, packs textures and generates an official-player preview. Its generated SKILL embeds scripts; this skill instead keeps executable files separate. The upstream LICENSE is PolyForm Noncommercial 1.0.0; no upstream source or character assets are copied into this package. Inspect its terms before any reuse. [Repository](https://github.com/GenielabsOpenSource/spine-animation-ai), [license](https://github.com/GenielabsOpenSource/spine-animation-ai/blob/main/LICENSE).

Do not add an external image-generation requirement to ordinary frontend builds. The upstream full-image splitting path sends an image to a provider and may alter identity; it is not deterministic segmentation. A flat image cannot become a guaranteed production rig through a format conversion.
