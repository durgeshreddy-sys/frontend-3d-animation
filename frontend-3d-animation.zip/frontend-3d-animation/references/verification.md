# Verification workflow

Validate the actual task, not just this package's examples.

1. Inventory assets and source permissions; inspect neutral poses and camera framing.
2. Validate custom motion data with `scripts/validate_motion.py`. For GLB use a glTF validator plus the actual loader. Check rig references, missing dependencies, durations and pose samples.
3. Run the project's build/type/lint checks as configured. Run relevant behavioral tests without installing unnecessary frameworks into an established app.
4. In a browser inspect desktop, 390px mobile and short landscape; confirm no horizontal overflow and visible controls. Capture meaningful key poses and interaction release frames, not just the initial load.
5. Test play/pause, seek, speed, fast mode selection, keyboard, pointer capture/cancel, reduced-motion changes, hidden-tab return, failed loading and unavailable/lost renderer.
6. Export and reimport; compare clip names, durations and sampled transforms. Data validity does not prove smooth contact or visual fidelity.
7. Measure target-device frame time and resource use. Headless software-rendered Chromium is not a mobile GPU performance benchmark.

Use report states `pass`, `fail`, `not-run`, `unmeasured`, with command/device/evidence. Record automatic fixes. Do not label unsupported formats successful because metadata parsing succeeded.

For a gait, inspect contact in world space, pose/velocity wrap, support leg, weight transfer, knee limits and arm opposition. For shaders, inspect alpha edges, normals, shadows and culling. For camera stories, test reverse scroll, segment transitions and reduced-motion document height.
