# Tool selection from the supplied motion-studio screenshot

The screenshot is a list of possible tools, not proof that combining them is free, compatible or necessary. The links below identify the visible projects. The screenshot does not uniquely identify “Muse”; no Muse API or integration is assumed. Reviewed 2026-11-26.

| Project | Good use | Relationship to this skill |
|---|---|---|
| [anime.js](https://github.com/juliangarnier/anime) | DOM/SVG timelines and coordinated UI motion | Optional UI owner; never compete with the camera controller |
| [react-spring](https://github.com/pmndrs/react-spring) | Interruptible springs in React | Optional `@react-spring/three`; use compatible peers; don't add it for one small spring |
| [PixiJS](https://github.com/pixijs/pixijs) | Rich 2D sprites/particles | Alternative 2D renderer, not required inside a 3D scene |
| [p5.js](https://github.com/processing/p5.js) | Generative sketches and art | Isolated sketch or generated texture; avoid a second always-on canvas without need |
| [Matter.js](https://github.com/liabru/matter-js) | 2D rigid-body collisions | Not a 3D physics solver; Three transforms alone do not simulate collision |
| [D3](https://github.com/d3/d3) | Data scales, layouts, visualizations | Use computation with React-owned DOM; avoid two libraries mutating the same elements |
| [Motion Canvas](https://github.com/motion-canvas/motion-canvas) | Code-authored explanatory animation/video | Separate rendered-media workflow, not core interactive 3D runtime |
| [Blender](https://github.com/blender/blender) | Model, rig, bake, retarget and export | Offline asset production; not a browser dependency |
| [Three.js](https://github.com/mrdoob/three.js) | Browser 3D renderer and animation | Core; Fiber is its React renderer, not another graphics engine |
| [Remotion Skills](https://github.com/remotion-dev/skills) | Agent guidance for React video production | Optional video-output workflow; verify Remotion's own current license separately |
| [Lottie Web](https://github.com/airbnb/lottie-web) | Playback of supported exported vector animation | Small UI assets; not arbitrary After Effects projects/effects or 3D scenes |
| [RIFE](https://github.com/hzwer/ECCV2022-RIFE) | Offline video frame interpolation | Does not increase interactive WebGL frame rate; inspect artifacts around occlusion/cuts |
| [MusicGen / AudioCraft](https://github.com/facebookresearch/audiocraft) | Offline audio generation | Separate compute and model-weight requirements; inspect weights' license, not just code |
| [Tone.js](https://github.com/Tonejs/Tone.js) | Browser synthesis and scheduled sound | Optional, user-activated audio context; pause/mute and schedule by audio clock |

Only install an extra tool after naming the specific missing capability. Use one animation owner per property and one rendering loop per renderer. Synchronize clocks explicitly when exported video/audio is involved. Package availability does not establish permission for bundled models, generated media or source artwork. The starter deliberately runs without any of these optional tools beyond Three.js.
